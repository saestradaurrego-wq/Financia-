# Financia — publicación web

Este paquete contiene `index.html`, listo para publicar como sitio estático. El diseño ya incluye adaptación para móviles y navegación inferior en pantallas pequeñas.

## Publicarlo gratis con GitHub Pages

1. Entra en https://github.com e inicia sesión.
2. Crea un repositorio nuevo llamado `financia` y selecciona **Public**.
3. Dentro del repositorio, usa **Add file → Upload files** y sube `index.html` (puedes descomprimir este ZIP primero).
4. Abre **Settings → Pages**. En **Build and deployment**, elige **Deploy from a branch**, selecciona `main` y `/ (root)`, y pulsa **Save**.
5. Espera unos minutos. GitHub mostrará el enlace publicado, normalmente con formato `https://TU-USUARIO.github.io/financia/`.

## Importante sobre tus datos

- La app guarda la información en el almacenamiento local del navegador (`localStorage`).
- Los datos no se sincronizan automáticamente entre teléfonos o navegadores. Para cambiar de dispositivo, usa la función de respaldo/exportación dentro de la app y restaura el respaldo en el otro dispositivo.
- No guardes datos financieros sensibles en un dispositivo compartido y conserva respaldos seguros.
- GitHub Pages publica los archivos del sitio; no convierte la app en una aplicación con base de datos privada o sincronización en la nube.
- La fuente tipográfica personalizada necesita conexión a internet; el resto del diseño usa fuentes de respaldo.
